﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RazorPagesUI.Models
{
    public class AddressModel
    {
        public string Password { get; set; }
    }
}
